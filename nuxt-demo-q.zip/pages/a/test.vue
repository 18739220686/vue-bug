<template>
    <div>
      <div>通过组件切换路由</div>
      <NuxtLink to="/b/pageA">Home page</NuxtLink>
      <br/>
      <br/>
      <div>通过组件切换路由带参1 </div>
      <NuxtLink to="/b/pageA?a=通过组件切换路由带参1">Home page</NuxtLink>
      <br/>
      <br/>
      <a @click="changeRouter1">通过脚本方式切换路由1 </a>
      <br/>
      <br/>
      <a @click="changeRouter2">通过脚本方式切换路由2 </a>
      <br/>
      <br/>
      <a @click="sendHttp">发送http请求 </a>

    </div>
</template>

<script>
    import service from "../../utils/axios";

    export default {
        name: "test",
        data() {
            return {}
        },
        mounted() {
        },
        methods: {
          changeRouter1(){
            this.$router.push({path:'b/pageA',query:{a:'通过脚本方式切换路由1'}})
          },
          changeRouter2(){
            this.$router.push({name:'b-pageA',params:{a:'通过脚本方式切换路由2'}})
          },
          sendHttp(){
            var form =  new FormData();
            form.append("userName",'admin')
            form.append("password",'e10adc3949ba59abbe56e057f20f883e')
            service.post('/login',form).then(res=>{
              console.log(res.data)
            });
          }
        },
    }
</script>

<style scoped>

</style>
