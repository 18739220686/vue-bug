<template>
  <div>
    <div>pageA</div>
    <div>参数</div>
    <div>a:{{a}}</div>
  </div>
</template>

<script>
  export default {
    name: "pageA",
    data() {
      return {
        a: ''
      }
    },
    mounted() {
      if (this.$route.query.a) {
        this.a = this.$route.query.a
      }
      if (this.$route.params.a) {
        this.a = this.$route.params.a
      }
    },
    methods: {},
  }
</script>

<style scoped>

</style>
